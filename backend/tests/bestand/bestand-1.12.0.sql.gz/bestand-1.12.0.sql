BEGIN TRANSACTION;
CREATE TABLE api_keys (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	scope VARCHAR(8) NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	prefix VARCHAR(16) NOT NULL, 
	created_at DATETIME NOT NULL, 
	last_used_at DATETIME, 
	expires_at DATETIME, 
	blocked_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES users (id) ON DELETE CASCADE, 
	UNIQUE (token_hash)
);
INSERT INTO "api_keys" VALUES(1,2,'Skript','read','ce1fa42c357ef1f1b3190e89715f5a96035dab410c534e396285ce9132d2e832','npk_best','2026-11-24 19:36:35.628111',NULL,NULL,NULL);
CREATE TABLE auth_sessions (
	id INTEGER NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	account_id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	last_seen_at DATETIME NOT NULL, 
	ip VARCHAR(64) NOT NULL, 
	user_agent VARCHAR(255) NOT NULL, 
	uid VARCHAR(32) DEFAULT '' NOT NULL, 
	remember BOOLEAN DEFAULT 1 NOT NULL, 
	stage VARCHAR(8) DEFAULT 'full' NOT NULL, 
	second_factor_by_provider BOOLEAN DEFAULT 0 NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (token_hash), 
	FOREIGN KEY(account_id) REFERENCES users (id) ON DELETE CASCADE
);
INSERT INTO "auth_sessions" VALUES(1,'6b7f921d2c8ac4af7e8b26397e42544d076bec0ee06dec448acd243a17af60f8',1,'2026-11-24 19:36:35.016920','2026-12-24 19:36:35.016920','2026-11-24 19:36:35.016920','198.51.100.10','testclient','007e77838df8f0d914a63be1b985a3c7',1,'full',0);
INSERT INTO "auth_sessions" VALUES(2,'34d4766fed34579a20fe9ed653f79566755621f4779dda1b4796fb55d27d3f67',2,'2026-11-24 19:36:35.597920','2026-12-24 19:36:35.597920','2026-11-24 19:36:35.597920','198.51.100.21','testclient','f06ecc539b456475b43116021a6a0dbb',1,'full',0);
INSERT INTO "auth_sessions" VALUES(3,'87f2f743c6cd2880bc926395c05f06dd02f1503a8cb113165468faed5387abab',3,'2026-11-24 19:36:35.684669','2026-12-24 19:36:35.684669','2026-11-24 19:36:35.684669','198.51.100.22','testclient','37043abbee5fd236e06b9fab09e44aaf',1,'full',0);
INSERT INTO "auth_sessions" VALUES(4,'0d30a388cc0e7cf56fb7fd7676b2d0bba6d6ddea59375bd9e595a4cd3c242c85',4,'2026-11-24 19:36:35.819712','2026-12-24 19:36:35.819712','2026-11-24 19:36:35.819712','198.51.100.23','testclient','033f597058ae7e65723eaa92e7ab5fe9',1,'full',0);
INSERT INTO "auth_sessions" VALUES(5,'3eb0d1dca5904cf5e704213b23331415a3fc24cd70ad0288563bb776b5b9bc06',5,'2026-11-24 19:36:35.873519','2026-12-24 19:36:35.873519','2026-11-24 19:36:35.873519','198.51.100.24','testclient','0ba0b884d5e260a2b3b7c383bcf38649',1,'full',0);
INSERT INTO "auth_sessions" VALUES(6,'e69769aa53194616218b418c5f6a0e449517c8bf3b7e63ea5d37ff5927c2b6d5',6,'2026-11-24 19:36:35.945408','2026-12-24 19:36:35.945408','2026-11-24 19:36:35.945408','198.51.100.25','testclient','7926c51ddf5f68f4cfc7d05cb7d70d1b',1,'full',0);
INSERT INTO "auth_sessions" VALUES(7,'de5d7997d7771c5a7c2fb631c191b6368242caf6612bdc8a33b1853d088f3ede',7,'2026-11-24 19:36:36.084488','2026-12-24 19:36:36.084488','2026-11-24 19:36:36.084488','198.51.100.60','testclient','c8fb31879fdf4c3fe9858056106e8add',1,'full',1);
INSERT INTO "auth_sessions" VALUES(8,'9c156f0f4567271f2e6cbf818e5a119a5af7da9c3e679be9d8cf2636c71eb01e',8,'2026-11-24 19:36:36.130483','2026-12-24 19:36:36.130483','2026-11-24 19:36:36.130483','198.51.100.27','testclient','44f6777d35c17a668f0eaa7916c0267c',1,'full',0);
CREATE TABLE counters (
	name VARCHAR(32) NOT NULL, 
	value INTEGER NOT NULL, 
	PRIMARY KEY (name)
);
CREATE TABLE deadline_snoozes (
	id INTEGER NOT NULL, 
	date_id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	until DATE NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_deadline_snoozes UNIQUE (date_id, user_id), 
	FOREIGN KEY(date_id) REFERENCES document_dates (id) ON DELETE CASCADE, 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE
);
CREATE TABLE devices (
	id INTEGER NOT NULL, 
	uid VARCHAR(32) NOT NULL, 
	account_id INTEGER NOT NULL, 
	name VARCHAR(80) NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	prefix VARCHAR(16) NOT NULL, 
	created_at DATETIME NOT NULL, 
	last_used_at DATETIME, 
	revoked_at DATETIME, 
	via VARCHAR(40) DEFAULT 'token' NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES users (id) ON DELETE CASCADE, 
	UNIQUE (token_hash)
);
INSERT INTO "devices" VALUES(1,'92e57c3e0cab1b9620f4fc9228a49184',2,'iPhone von Anna','b66ee60449db01fb11dc857947a247b91a1937f39df658f58fefb0725adffb43','npd_best','2026-11-24 19:36:35.636838',NULL,NULL,'token');
CREATE TABLE document_dates (
	id INTEGER NOT NULL, 
	document_id INTEGER NOT NULL, 
	kind VARCHAR(16) NOT NULL, 
	date DATE NOT NULL, 
	notice_n INTEGER, 
	notice_unit VARCHAR(8), 
	renew_months INTEGER, 
	notice_date DATE, 
	done_at DATETIME, 
	done_by INTEGER, 
	renewed_from DATE, 
	renew_anchor DATE, 
	manual BOOLEAN DEFAULT 0 NOT NULL, 
	note VARCHAR(200) DEFAULT '' NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_document_dates_kind UNIQUE (document_id, kind), 
	FOREIGN KEY(document_id) REFERENCES documents (id) ON DELETE CASCADE, 
	FOREIGN KEY(done_by) REFERENCES users (id) ON DELETE SET NULL
);
CREATE TABLE document_numbers (
	id INTEGER NOT NULL, 
	document_id INTEGER NOT NULL, 
	kind VARCHAR(10) NOT NULL, 
	value VARCHAR(64) NOT NULL, 
	compare VARCHAR(64) NOT NULL, 
	origin VARCHAR(8) NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(document_id) REFERENCES documents (id) ON DELETE CASCADE
);
CREATE TABLE document_tags (
	document_id INTEGER NOT NULL, 
	tag_id INTEGER NOT NULL, 
	PRIMARY KEY (document_id, tag_id), 
	FOREIGN KEY(document_id) REFERENCES documents (id) ON DELETE CASCADE, 
	FOREIGN KEY(tag_id) REFERENCES tags (id) ON DELETE CASCADE
);
CREATE TABLE documents (
	id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
	vault_id INTEGER NOT NULL, 
	owner_id INTEGER, 
	title VARCHAR(200) NOT NULL, 
	sender_id INTEGER, 
	kind_id INTEGER, 
	date DATE, 
	amount INTEGER, 
	currency VARCHAR(3) DEFAULT 'EUR' NOT NULL, 
	status VARCHAR(12) NOT NULL, 
	source VARCHAR(16) NOT NULL, 
	added_at DATETIME NOT NULL, 
	pages INTEGER NOT NULL, 
	current_version INTEGER NOT NULL, 
	suggest JSON, 
	trashed_at DATETIME, 
	trashed_status VARCHAR(12) DEFAULT '' NOT NULL, 
	change_seq INTEGER NOT NULL, 
	duplicate_of INTEGER, 
	duplicate_kind VARCHAR(8) DEFAULT '' NOT NULL, 
	process_error VARCHAR(24) DEFAULT '' NOT NULL, 
	files_state VARCHAR(8) DEFAULT '' NOT NULL, 
	FOREIGN KEY(vault_id) REFERENCES vaults (id) ON DELETE RESTRICT, 
	FOREIGN KEY(owner_id) REFERENCES users (id) ON DELETE SET NULL, 
	FOREIGN KEY(sender_id) REFERENCES senders (id) ON DELETE SET NULL, 
	FOREIGN KEY(kind_id) REFERENCES kinds (id) ON DELETE SET NULL
);
CREATE TABLE einvoices (
	version_id INTEGER NOT NULL, 
	document_id INTEGER NOT NULL, 
	format VARCHAR(40) NOT NULL, 
	number VARCHAR(100) NOT NULL, 
	issued DATE, 
	due DATE, 
	seller VARCHAR(200) NOT NULL, 
	seller_vat VARCHAR(40) NOT NULL, 
	buyer VARCHAR(200) NOT NULL, 
	buyer_ref VARCHAR(100) NOT NULL, 
	iban VARCHAR(40) NOT NULL, 
	currency VARCHAR(3) NOT NULL, 
	net INTEGER, 
	tax INTEGER, 
	gross INTEGER, 
	payable INTEGER, 
	credit_note BOOLEAN NOT NULL, 
	lines JSON, 
	xml BLOB, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (version_id), 
	FOREIGN KEY(version_id) REFERENCES versions (id) ON DELETE CASCADE, 
	FOREIGN KEY(document_id) REFERENCES documents (id) ON DELETE CASCADE
);
CREATE TABLE email_confirmations (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	address VARCHAR(255) NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (account_id), 
	FOREIGN KEY(account_id) REFERENCES users (id) ON DELETE CASCADE, 
	UNIQUE (token_hash)
);
INSERT INTO "email_confirmations" VALUES(1,6,'emil@example.com','a7ab208962270d7f0b786a084221b9975495d3b2c2faa5976884843771de1daa','2026-11-24 19:36:35.963588','2026-11-25 19:36:35.963306');
CREATE TABLE events (
	id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
	document_id INTEGER NOT NULL, 
	user_id INTEGER, 
	by_link VARCHAR(100) DEFAULT '' NOT NULL, 
	at DATETIME NOT NULL, 
	action VARCHAR(24) NOT NULL, 
	detail JSON, 
	FOREIGN KEY(document_id) REFERENCES documents (id) ON DELETE CASCADE, 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE SET NULL
);
CREATE TABLE export_links (
	id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
	export_id INTEGER NOT NULL, 
	recipient VARCHAR(100) NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	token_enc VARCHAR(400) NOT NULL, 
	until DATETIME NOT NULL, 
	opened_count INTEGER NOT NULL, 
	last_opened_at DATETIME, 
	created_by INTEGER, 
	created_at DATETIME NOT NULL, 
	revoked_at DATETIME, 
	FOREIGN KEY(export_id) REFERENCES exports (id) ON DELETE CASCADE, 
	UNIQUE (token_hash), 
	FOREIGN KEY(created_by) REFERENCES users (id) ON DELETE SET NULL
);
CREATE TABLE exports (
	id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
	user_id INTEGER NOT NULL, 
	state VARCHAR(10) NOT NULL, 
	params JSON, 
	vault_ids JSON, 
	language VARCHAR(8) NOT NULL, 
	documents INTEGER NOT NULL, 
	size INTEGER NOT NULL, 
	total INTEGER NOT NULL, 
	file VARCHAR(80) NOT NULL, 
	error VARCHAR(40) NOT NULL, 
	created_at DATETIME NOT NULL, 
	finished_at DATETIME, 
	expires_at DATETIME NOT NULL, 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE
);
CREATE TABLE intake_items (
	id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
	document_id INTEGER, 
	source VARCHAR(8) NOT NULL, 
	"key" VARCHAR(600) NOT NULL, 
	state VARCHAR(8) NOT NULL, 
	sha256 VARCHAR(64) NOT NULL, 
	size INTEGER NOT NULL, 
	mtime_ns INTEGER NOT NULL, 
	message VARCHAR(64) NOT NULL, 
	unknown BOOLEAN NOT NULL, 
	detail JSON, 
	at DATETIME NOT NULL, 
	FOREIGN KEY(document_id) REFERENCES documents (id) ON DELETE SET NULL
);
CREATE TABLE invites (
	id INTEGER NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	email VARCHAR(255) NOT NULL, 
	created_by INTEGER, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (token_hash), 
	FOREIGN KEY(created_by) REFERENCES users (id) ON DELETE SET NULL
);
INSERT INTO "invites" VALUES(1,'24f63783c6066622d3bb2fdde23ac7e4b6e853f8025e0a5706a2d591572a4b5a','neu@example.com',1,'2026-11-24 19:36:36.435668','2026-12-01 19:36:36.435417');
INSERT INTO "invites" VALUES(2,'3c096bd0c4ec5b926921910940e8113067a836c9714e72e4f901236ee369df6d','',1,'2026-11-24 19:36:36.453966','2026-12-01 19:36:36.451897');
CREATE TABLE jobs (
	id INTEGER NOT NULL, 
	kind VARCHAR(16) NOT NULL, 
	ref INTEGER NOT NULL, 
	payload JSON, 
	state VARCHAR(8) NOT NULL, 
	attempts INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	started_at DATETIME, 
	finished_at DATETIME, 
	error VARCHAR(300) DEFAULT '' NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE kinds (
	id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
	"key" VARCHAR(32) NOT NULL, 
	name VARCHAR(60) NOT NULL, 
	name_key VARCHAR(160) NOT NULL, 
	hue INTEGER NOT NULL, 
	position INTEGER NOT NULL, 
	vault_id INTEGER, 
	created_by INTEGER, 
	keep_years INTEGER, 
	keep_new_only BOOLEAN DEFAULT 0 NOT NULL, 
	auto_trash BOOLEAN DEFAULT 0 NOT NULL, 
	FOREIGN KEY(vault_id) REFERENCES vaults (id) ON DELETE CASCADE, 
	FOREIGN KEY(created_by) REFERENCES users (id) ON DELETE SET NULL
);
CREATE TABLE link_documents (
	id INTEGER NOT NULL, 
	link_id INTEGER NOT NULL, 
	document_id INTEGER NOT NULL, 
	number INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_link_document UNIQUE (link_id, document_id), 
	CONSTRAINT uq_link_document_number UNIQUE (link_id, number), 
	FOREIGN KEY(link_id) REFERENCES links (id) ON DELETE CASCADE, 
	FOREIGN KEY(document_id) REFERENCES documents (id) ON DELETE CASCADE
);
CREATE TABLE links (
	id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
	document_id INTEGER NOT NULL, 
	recipient VARCHAR(100) NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	token_enc VARCHAR(400) DEFAULT '' NOT NULL, 
	until DATETIME NOT NULL, 
	allow_download BOOLEAN DEFAULT 1 NOT NULL, 
	opened_count INTEGER NOT NULL, 
	last_opened_at DATETIME, 
	created_by INTEGER, 
	created_at DATETIME NOT NULL, 
	revoked_at DATETIME, 
	FOREIGN KEY(document_id) REFERENCES documents (id) ON DELETE CASCADE, 
	UNIQUE (token_hash), 
	FOREIGN KEY(created_by) REFERENCES users (id) ON DELETE SET NULL
);
CREATE TABLE mail_senders (
	id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
	user_id INTEGER NOT NULL, 
	address VARCHAR(255) NOT NULL, 
	address_key VARCHAR(255) NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	expires_at DATETIME, 
	confirmed_at DATETIME, 
	created_at DATETIME NOT NULL, 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE
);
CREATE TABLE notes (
	id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
	document_id INTEGER NOT NULL, 
	user_id INTEGER, 
	text TEXT NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME, 
	FOREIGN KEY(document_id) REFERENCES documents (id) ON DELETE CASCADE, 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE SET NULL
);
CREATE TABLE numbers_read (
	document_id INTEGER NOT NULL, 
	digest VARCHAR(40) NOT NULL, 
	PRIMARY KEY (document_id), 
	FOREIGN KEY(document_id) REFERENCES documents (id) ON DELETE CASCADE
);
CREATE TABLE oidc_links (
	id INTEGER NOT NULL, 
	provider_id INTEGER NOT NULL, 
	subject VARCHAR(255) NOT NULL, 
	account_id INTEGER NOT NULL, 
	issuer VARCHAR(500) NOT NULL, 
	email VARCHAR(320), 
	created_at DATETIME NOT NULL, 
	last_used_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (provider_id, subject), 
	UNIQUE (provider_id, account_id), 
	FOREIGN KEY(provider_id) REFERENCES oidc_providers (id) ON DELETE CASCADE, 
	FOREIGN KEY(account_id) REFERENCES users (id) ON DELETE CASCADE
);
INSERT INTO "oidc_links" VALUES(1,1,'bestand-fritz',7,'https://sso.example.com','fritz@example.com','2026-11-24 19:36:36.075958',NULL);
INSERT INTO "oidc_links" VALUES(2,1,'bestand-greta',8,'https://sso.example.com','greta@example.com','2026-11-24 19:36:36.243899',NULL);
CREATE TABLE oidc_providers (
	id INTEGER NOT NULL, 
	slug VARCHAR(40) NOT NULL, 
	label VARCHAR(64) NOT NULL, 
	issuer VARCHAR(500) NOT NULL, 
	client_id VARCHAR(255) NOT NULL, 
	client_secret_enc TEXT NOT NULL, 
	scopes VARCHAR(500) NOT NULL, 
	enabled BOOLEAN NOT NULL, 
	auto_create BOOLEAN NOT NULL, 
	trusts_second_factor BOOLEAN NOT NULL, 
	managed VARCHAR(20) NOT NULL, 
	position INTEGER NOT NULL, 
	redirect_path VARCHAR(300) NOT NULL, 
	registered_redirect VARCHAR(500) DEFAULT '' NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (slug)
);
INSERT INTO "oidc_providers" VALUES(1,'sso','SSO','https://sso.example.com','nexpaper-bestand','d86a39a82862e25f0220c6bdf0aa2db960b10e83e3374a45a807552cd4e3ac41f18bb448b70840bdb105','openid profile email',1,1,1,'',0,'','','2026-11-24 19:36:35.536266');
CREATE TABLE pairings (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	kind VARCHAR(8) NOT NULL, 
	code_hash VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	used_at DATETIME, 
	device_id INTEGER, 
	client_id VARCHAR(64) DEFAULT '' NOT NULL, 
	redirect_uri VARCHAR(300) DEFAULT '' NOT NULL, 
	challenge VARCHAR(128) DEFAULT '' NOT NULL, 
	device_name VARCHAR(80) DEFAULT '' NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES users (id) ON DELETE CASCADE, 
	UNIQUE (code_hash), 
	FOREIGN KEY(device_id) REFERENCES devices (id) ON DELETE SET NULL
);
CREATE TABLE paperless_items (
	id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
	origin VARCHAR(64) NOT NULL, 
	paperless_id INTEGER NOT NULL, 
	document_id INTEGER, 
	state VARCHAR(8) NOT NULL, 
	reason VARCHAR(32) NOT NULL, 
	inbox BOOLEAN NOT NULL, 
	at DATETIME NOT NULL, 
	FOREIGN KEY(document_id) REFERENCES documents (id) ON DELETE SET NULL
);
CREATE TABLE passkeys (
	id INTEGER NOT NULL, 
	uid VARCHAR(32) NOT NULL, 
	user_id INTEGER NOT NULL, 
	credential_id BLOB NOT NULL, 
	public_key BLOB NOT NULL, 
	sign_count INTEGER NOT NULL, 
	name VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL, 
	last_used_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE
);
CREATE TABLE password_resets (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	created_by INTEGER, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES users (id) ON DELETE CASCADE, 
	UNIQUE (token_hash), 
	FOREIGN KEY(created_by) REFERENCES users (id) ON DELETE SET NULL
);
INSERT INTO "password_resets" VALUES(1,2,'a6ec3d778a8e7d368cfe1a367295239b86ac01049f430fd4eb68e1b08e74262b',NULL,'2026-11-24 19:36:35.645151','2026-11-25 19:36:35.644531');
INSERT INTO "password_resets" VALUES(2,3,'376a41e67aa5d32fff713a04907d70dd643205e7a7b582f0841effa5ca6838e8',1,'2026-11-24 19:36:35.770051','2026-11-25 19:36:35.769796');
CREATE TABLE pdf_passwords (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	name VARCHAR(60) NOT NULL, 
	sealed TEXT NOT NULL, 
	created_at DATETIME NOT NULL, 
	last_matched_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE
);
CREATE TABLE pins (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	document_id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_pins_user_document UNIQUE (user_id, document_id), 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE, 
	FOREIGN KEY(document_id) REFERENCES documents (id) ON DELETE CASCADE
);
CREATE TABLE push_devices (
	id INTEGER NOT NULL, 
	uid VARCHAR(32) NOT NULL, 
	user_id INTEGER NOT NULL, 
	endpoint_key VARCHAR(64) NOT NULL, 
	content TEXT NOT NULL, 
	created_at DATETIME NOT NULL, 
	last_used_at DATETIME, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_push_devices_uid UNIQUE (uid), 
	CONSTRAINT uq_push_devices_user_endpoint UNIQUE (user_id, endpoint_key), 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE
);
CREATE TABLE related (
	id INTEGER NOT NULL, 
	low_id INTEGER NOT NULL, 
	high_id INTEGER NOT NULL, 
	created_by INTEGER, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_related_pair UNIQUE (low_id, high_id), 
	FOREIGN KEY(low_id) REFERENCES documents (id) ON DELETE CASCADE, 
	FOREIGN KEY(high_id) REFERENCES documents (id) ON DELETE CASCADE, 
	FOREIGN KEY(created_by) REFERENCES users (id) ON DELETE SET NULL
);
CREATE TABLE related_dismissed (
	id INTEGER NOT NULL, 
	low_id INTEGER NOT NULL, 
	high_id INTEGER NOT NULL, 
	created_by INTEGER, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_related_dismissed_pair UNIQUE (low_id, high_id), 
	FOREIGN KEY(low_id) REFERENCES documents (id) ON DELETE CASCADE, 
	FOREIGN KEY(high_id) REFERENCES documents (id) ON DELETE CASCADE, 
	FOREIGN KEY(created_by) REFERENCES users (id) ON DELETE SET NULL
);
CREATE TABLE reminder_mutes (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	vault_id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_reminder_mutes UNIQUE (user_id, vault_id), 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE, 
	FOREIGN KEY(vault_id) REFERENCES vaults (id) ON DELETE CASCADE
);
CREATE TABLE reminder_settings (
	user_id INTEGER NOT NULL, 
	rhythm VARCHAR(8) NOT NULL, 
	push BOOLEAN NOT NULL, 
	mail BOOLEAN NOT NULL, 
	lead_due INTEGER NOT NULL, 
	lead_cancel INTEGER NOT NULL, 
	lead_warranty INTEGER NOT NULL, 
	same_day BOOLEAN NOT NULL, 
	muted_shared BOOLEAN NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (user_id), 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE
);
CREATE TABLE reminders_sent (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	date_id INTEGER, 
	stage VARCHAR(8) NOT NULL, 
	day DATE NOT NULL, 
	sent_day DATE NOT NULL, 
	sent_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE, 
	FOREIGN KEY(date_id) REFERENCES document_dates (id) ON DELETE CASCADE
);
CREATE TABLE rules (
	id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
	vault_id INTEGER, 
	created_by INTEGER, 
	position INTEGER NOT NULL, 
	"on" BOOLEAN NOT NULL, 
	hits INTEGER NOT NULL, 
	last_hit_at DATETIME, 
	"when" JSON NOT NULL, 
	"then" JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	FOREIGN KEY(vault_id) REFERENCES vaults (id) ON DELETE CASCADE, 
	FOREIGN KEY(created_by) REFERENCES users (id) ON DELETE SET NULL
);
CREATE TABLE saved_searches (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	name VARCHAR(60) NOT NULL, 
	"query" VARCHAR(1200) NOT NULL, 
	position INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE
);
CREATE TABLE search_entries (
	document_id INTEGER NOT NULL, 
	seq INTEGER NOT NULL, 
	digest VARCHAR(40) NOT NULL, 
	PRIMARY KEY (document_id), 
	FOREIGN KEY(document_id) REFERENCES documents (id) ON DELETE CASCADE
);
CREATE TABLE senders (
	id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
	vault_id INTEGER NOT NULL, 
	name VARCHAR(160) NOT NULL, 
	"key" VARCHAR(400) NOT NULL, 
	created_by INTEGER, 
	memo VARCHAR(500) DEFAULT '' NOT NULL, 
	FOREIGN KEY(vault_id) REFERENCES vaults (id) ON DELETE CASCADE, 
	FOREIGN KEY(created_by) REFERENCES users (id) ON DELETE SET NULL
);
CREATE TABLE settings (
	"key" VARCHAR(64) NOT NULL, 
	value JSON, 
	PRIMARY KEY ("key")
);
INSERT INTO "settings" VALUES('two_factor_required','false');
INSERT INTO "settings" VALUES('api_keys_allowed','true');
INSERT INTO "settings" VALUES('password_login','true');
CREATE TABLE shares (
	document_id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	"right" VARCHAR(8) NOT NULL, 
	created_by INTEGER, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (document_id, user_id), 
	FOREIGN KEY(document_id) REFERENCES documents (id) ON DELETE CASCADE, 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE, 
	FOREIGN KEY(created_by) REFERENCES users (id) ON DELETE SET NULL
);
CREATE TABLE tags (
	id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
	vault_id INTEGER NOT NULL, 
	name VARCHAR(40) NOT NULL, 
	"key" VARCHAR(120) NOT NULL, 
	created_by INTEGER, 
	FOREIGN KEY(vault_id) REFERENCES vaults (id) ON DELETE CASCADE, 
	FOREIGN KEY(created_by) REFERENCES users (id) ON DELETE SET NULL
);
CREATE TABLE tombstones (
	seq INTEGER NOT NULL, 
	kind VARCHAR(16) NOT NULL, 
	document_id INTEGER, 
	vault_id INTEGER, 
	user_id INTEGER, 
	at DATETIME NOT NULL, 
	PRIMARY KEY (seq)
);
CREATE TABLE upload_requests (
	id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
	user_id INTEGER NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	token_enc VARCHAR(400) NOT NULL, 
	address VARCHAR(255) NOT NULL, 
	until DATETIME NOT NULL, 
	max_files INTEGER NOT NULL, 
	received INTEGER NOT NULL, 
	last_used_at DATETIME, 
	told_at DATETIME, 
	revoked_at DATETIME, 
	created_at DATETIME NOT NULL, 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE, 
	UNIQUE (token_hash)
);
CREATE TABLE uploads (
	id VARCHAR(32) NOT NULL, 
	user_id INTEGER NOT NULL, 
	vault_id INTEGER NOT NULL, 
	filename VARCHAR(200) NOT NULL, 
	size INTEGER NOT NULL, 
	sha256 VARCHAR(64) NOT NULL, 
	received INTEGER NOT NULL, 
	source VARCHAR(8) NOT NULL, 
	state VARCHAR(10) NOT NULL, 
	document_id INTEGER, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	api_key_id INTEGER, 
	target_document_id INTEGER, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE, 
	FOREIGN KEY(vault_id) REFERENCES vaults (id) ON DELETE CASCADE
);
CREATE TABLE users (
	id INTEGER NOT NULL, 
	name VARCHAR(64) NOT NULL, 
	display_name VARCHAR(80) NOT NULL, 
	whats_new_seen VARCHAR(32) NOT NULL, 
	role VARCHAR(16) NOT NULL, 
	sign_in VARCHAR(16) NOT NULL, 
	password_hash VARCHAR(255) NOT NULL, 
	email VARCHAR(255) NOT NULL, 
	email_confirmed_at DATETIME, 
	email_from_provider BOOLEAN DEFAULT 0 NOT NULL, 
	oidc_subject VARCHAR(255) NOT NULL, 
	language VARCHAR(16) NOT NULL, 
	profile JSON, 
	created_at DATETIME NOT NULL, 
	last_seen_at DATETIME, 
	failed_logins INTEGER NOT NULL, 
	locked_until DATETIME, 
	blocked_at DATETIME, 
	totp_secret_enc TEXT NOT NULL, 
	totp_recovery TEXT NOT NULL, 
	totp_last_step INTEGER NOT NULL, 
	avatar BLOB, 
	avatar_at DATETIME, 
	signed_in_before BOOLEAN DEFAULT 0 NOT NULL, 
	passkey_handle VARCHAR(64) DEFAULT '' NOT NULL, 
	ai_allowed BOOLEAN DEFAULT 1 NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (name)
);
INSERT INTO "users" VALUES(1,'betreiber','','1.12.0','operator','password','$argon2id$v=19$m=1024,t=1,p=1$la/T9q4cNtMg2SKmOiw5fQ$Cc40bcHqQekNaPu0sjAzzfgJCJaC3Av8MNpi8nNFaDo','betrieb@example.com','2026-11-24 19:36:35.045657',0,'','de',NULL,'2026-11-24 19:36:35.001170','2026-11-24 19:36:36.404554',0,NULL,NULL,'e275f3181e008142b888a42b66ee2517c843ead109be7a40d570a9fa4d86efc92f6e17b449f27b3d1324bcfdc7ac0d7fe03c963d7fa0a0e2f266de5d','["h1:9bddf16e74281a2daf84d5e9d1ef5b126c84d2c024d7cdb1745891e255a54282", "h1:4ed18b2f33ed56431430eedbdf8acfbf34448e06935db09911ea646299ba871a", "h1:4cdaf492604eece4836b045b32e4d4e496b04e3da0ab5b60899bd8f82d6ca2a4", "h1:e89288f135f32bd1678fa93429e715aab3f040f01459c3d24cfe00434599bac0", "h1:9f1a00fc06b98dc79a27d4a4f50a3a3d5c5a65466af3e7c6a44c94f7d1a0de19", "h1:ccf17f43cacfacd5647f8ad63ad10c92476e5f56740700572685a339ca297754", "h1:9e7d6add6d09143333c085ecb979b8a374da8c7ec5a919f6d9fbaa3d4b1cea28", "h1:248d08b82160355cd77f102ae084197fe892342f1c07d78ac5887e3800649268"]',59851633,NULL,NULL,1,'',1);
INSERT INTO "users" VALUES(2,'anna','','1.12.0','member','password','$argon2id$v=19$m=1024,t=1,p=1$gJ1ax+t/u7UYJ2q68df0Sg$7Ary9o80cblC0tSC9zRDkqrSf8hwnLz8f3qmLA0mEss','anna@example.com','2026-11-24 19:36:35.621777',0,'','',NULL,'2026-11-24 19:36:35.587904','2026-11-24 19:36:35.597920',0,NULL,NULL,'','',0,NULL,NULL,1,'',1);
INSERT INTO "users" VALUES(3,'ben','','1.12.0','member','password','$argon2id$v=19$m=1024,t=1,p=1$EmYQX1GV6v4EYJ+5eEXKtw$dmCsik6WlyfbOY1B/V+f2H5ozhKV4MPs7oFyRn+iGNc','ben@example.net',NULL,0,'','',NULL,'2026-11-24 19:36:35.675099','2026-11-24 19:36:35.684669',0,NULL,NULL,'','',0,NULL,NULL,1,'',1);
INSERT INTO "users" VALUES(4,'carla','','1.12.0','member','password','$argon2id$v=19$m=1024,t=1,p=1$qaRrtv3TTi1iQ+DB/5khSw$WhyTcCAHMk1PJmUqeZlrHjrcLF6XHTeJEcGDeBi/oE0','familie@example.org',NULL,0,'','',NULL,'2026-11-24 19:36:35.808254','2026-11-24 19:36:35.819712',0,NULL,NULL,'','',0,NULL,NULL,1,'',1);
INSERT INTO "users" VALUES(5,'dora','','1.12.0','member','password','$argon2id$v=19$m=1024,t=1,p=1$MkIBX3cXk/iefxWkERI3eg$2FE8eZRm1nBrGjUkc9s99JU3PcW3UFKTkHBBLvAmMBE','Familie@Example.org','2026-11-24 19:36:35.897451',0,'','',NULL,'2026-11-24 19:36:35.861058','2026-11-24 19:36:35.873519',0,NULL,NULL,'','',0,NULL,NULL,1,'',1);
INSERT INTO "users" VALUES(6,'emil','','1.12.0','member','password','$argon2id$v=19$m=1024,t=1,p=1$ydpSHFEonqEuGNKcU2u+mA$gYbAW+0FPpsMbieTBxqd6jHkd0d/eNkj3Z4St2KVvFM','',NULL,0,'','',NULL,'2026-11-24 19:36:35.934591','2026-11-24 19:36:35.945408',0,NULL,NULL,'','',0,NULL,NULL,1,'',1);
INSERT INTO "users" VALUES(7,'fritz','','1.12.0','member','oidc','','fritz@example.com',NULL,1,'','',NULL,'2026-11-24 19:36:36.072997','2026-11-24 19:36:36.084488',0,NULL,NULL,'','',0,NULL,NULL,1,'',1);
INSERT INTO "users" VALUES(8,'greta','','1.12.0','member','password','$argon2id$v=19$m=1024,t=1,p=1$SS2lrO0Bw0FRvcnRAnpjpQ$xafMtto/YmDUPZ3WoqeFPHzi4pOUMYQTwxrHtyhQ8rI','greta@example.com',NULL,0,'','',NULL,'2026-11-24 19:36:36.119903','2026-11-24 19:36:36.154287',0,NULL,NULL,'','',0,NULL,NULL,1,'',1);
INSERT INTO "users" VALUES(9,'hans','','1.12.0','member','password','$argon2id$v=19$m=1024,t=1,p=1$auL0tNdn+M1EtdNuSqs3dA$Ia7YhM9caXSnwtGWD66CtBuDo4hi+OVfB4QpxEqrVYg','hans@example.com',NULL,0,'','',NULL,'2026-11-24 19:36:36.284118','2026-11-24 19:36:36.295359',0,NULL,'2026-11-24 19:36:36.326845','','',0,NULL,NULL,1,'',1);
CREATE TABLE vault_members (
	vault_id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	"right" VARCHAR(8) NOT NULL, 
	PRIMARY KEY (vault_id, user_id), 
	FOREIGN KEY(vault_id) REFERENCES vaults (id) ON DELETE CASCADE, 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE
);
INSERT INTO "vault_members" VALUES(1,1,'manage');
INSERT INTO "vault_members" VALUES(2,2,'manage');
INSERT INTO "vault_members" VALUES(3,3,'manage');
INSERT INTO "vault_members" VALUES(4,4,'manage');
INSERT INTO "vault_members" VALUES(5,5,'manage');
INSERT INTO "vault_members" VALUES(6,6,'manage');
INSERT INTO "vault_members" VALUES(7,7,'manage');
INSERT INTO "vault_members" VALUES(8,8,'manage');
INSERT INTO "vault_members" VALUES(9,9,'manage');
CREATE TABLE vaults (
	id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
	name VARCHAR(80) NOT NULL, 
	folder VARCHAR(64) NOT NULL, 
	icon VARCHAR(16) NOT NULL, 
	personal_of INTEGER, 
	created_at DATETIME NOT NULL, 
	created_by INTEGER, 
	FOREIGN KEY(personal_of) REFERENCES users (id) ON DELETE RESTRICT, 
	FOREIGN KEY(created_by) REFERENCES users (id) ON DELETE SET NULL
);
INSERT INTO "vaults" VALUES(1,'betreiber','betreiber','user',1,'2026-11-24 19:36:35.002234',1);
INSERT INTO "vaults" VALUES(2,'anna','anna','user',2,'2026-11-24 19:36:35.588463',2);
INSERT INTO "vaults" VALUES(3,'ben','ben','user',3,'2026-11-24 19:36:35.675615',3);
INSERT INTO "vaults" VALUES(4,'carla','carla','user',4,'2026-11-24 19:36:35.808918',4);
INSERT INTO "vaults" VALUES(5,'dora','dora','user',5,'2026-11-24 19:36:35.861684',5);
INSERT INTO "vaults" VALUES(6,'emil','emil','user',6,'2026-11-24 19:36:35.935352',6);
INSERT INTO "vaults" VALUES(7,'fritz','fritz','user',7,'2026-11-24 19:36:36.073655',7);
INSERT INTO "vaults" VALUES(8,'greta','greta','user',8,'2026-11-24 19:36:36.120431',8);
INSERT INTO "vaults" VALUES(9,'hans','hans','user',9,'2026-11-24 19:36:36.284644',9);
CREATE TABLE version_info (
	version_id INTEGER NOT NULL, 
	document_id INTEGER NOT NULL, 
	origin VARCHAR(12) NOT NULL, 
	from_n INTEGER, 
	state VARCHAR(12) NOT NULL, 
	error VARCHAR(24) NOT NULL, 
	detail JSON, 
	blanks JSON, 
	split_dismissed BOOLEAN NOT NULL, 
	PRIMARY KEY (version_id), 
	FOREIGN KEY(version_id) REFERENCES versions (id) ON DELETE CASCADE, 
	FOREIGN KEY(document_id) REFERENCES documents (id) ON DELETE CASCADE
);
CREATE TABLE version_texts (
	version_id INTEGER NOT NULL, 
	document_id INTEGER NOT NULL, 
	text TEXT NOT NULL, 
	pages INTEGER NOT NULL, 
	ocr_pages INTEGER NOT NULL, 
	languages VARCHAR(64) NOT NULL, 
	digest VARCHAR(40) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (version_id), 
	FOREIGN KEY(version_id) REFERENCES versions (id) ON DELETE CASCADE, 
	FOREIGN KEY(document_id) REFERENCES documents (id) ON DELETE CASCADE
);
CREATE TABLE versions (
	id INTEGER NOT NULL, 
	document_id INTEGER NOT NULL, 
	n INTEGER NOT NULL, 
	original_path VARCHAR(600) NOT NULL, 
	archive_path VARCHAR(600) DEFAULT '' NOT NULL, 
	sha256 VARCHAR(64) NOT NULL, 
	size INTEGER NOT NULL, 
	pages INTEGER NOT NULL, 
	created_by INTEGER, 
	created_at DATETIME NOT NULL, 
	note VARCHAR(200) DEFAULT '' NOT NULL, 
	phash VARCHAR(256) DEFAULT '' NOT NULL, 
	archive_sha256 VARCHAR(64) DEFAULT '' NOT NULL, 
	original_protected VARCHAR(10) DEFAULT '' NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_versions_n UNIQUE (document_id, n), 
	FOREIGN KEY(document_id) REFERENCES documents (id) ON DELETE CASCADE, 
	FOREIGN KEY(created_by) REFERENCES users (id) ON DELETE SET NULL
);
CREATE INDEX ix_tombstones_at ON tombstones (at);
CREATE INDEX ix_tombstones_vault ON tombstones (vault_id);
CREATE INDEX ix_tombstones_user ON tombstones (user_id);
CREATE INDEX ix_jobs_state ON jobs (state, id);
CREATE UNIQUE INDEX uq_jobs_waiting ON jobs (kind, ref) WHERE state = 'queued';
CREATE INDEX ix_auth_sessions_account_id ON auth_sessions (account_id);
CREATE UNIQUE INDEX uq_auth_sessions_uid ON auth_sessions (uid);
CREATE INDEX ix_oidc_links_provider_id ON oidc_links (provider_id);
CREATE INDEX ix_oidc_links_account_id ON oidc_links (account_id);
CREATE INDEX ix_passkeys_user_id ON passkeys (user_id);
CREATE UNIQUE INDEX uq_passkeys_uid ON passkeys (uid);
CREATE UNIQUE INDEX uq_passkeys_credential ON passkeys (credential_id);
CREATE INDEX ix_password_resets_account_id ON password_resets (account_id);
CREATE INDEX ix_api_keys_account_id ON api_keys (account_id);
CREATE INDEX ix_devices_account_id ON devices (account_id);
CREATE UNIQUE INDEX uq_devices_uid ON devices (uid);
CREATE INDEX ix_push_devices_user_id ON push_devices (user_id);
CREATE UNIQUE INDEX uq_vaults_folder ON vaults (lower(folder));
CREATE UNIQUE INDEX uq_vaults_personal ON vaults (personal_of);
CREATE UNIQUE INDEX uq_mail_senders_user_key ON mail_senders (user_id, address_key);
CREATE INDEX ix_mail_senders_key ON mail_senders (address_key);
CREATE INDEX ix_exports_user ON exports (user_id, state);
CREATE INDEX ix_saved_searches_user_id ON saved_searches (user_id);
CREATE INDEX ix_pdf_passwords_user_id ON pdf_passwords (user_id);
CREATE INDEX ix_upload_requests_user ON upload_requests (user_id);
CREATE INDEX ix_vault_members_user_id ON vault_members (user_id);
CREATE UNIQUE INDEX uq_senders_key ON senders (vault_id, "key");
CREATE UNIQUE INDEX uq_kinds_server ON kinds (name_key) WHERE vault_id IS NULL;
CREATE UNIQUE INDEX uq_kinds_vault ON kinds (vault_id, name_key) WHERE vault_id IS NOT NULL;
CREATE UNIQUE INDEX uq_tags_key ON tags (vault_id, "key");
CREATE INDEX ix_uploads_user ON uploads (user_id, state);
CREATE INDEX ix_pairings_account ON pairings (account_id, kind);
CREATE INDEX ix_export_links_export ON export_links (export_id);
CREATE INDEX ix_rules_vault ON rules (vault_id, position);
CREATE INDEX ix_reminder_mutes_vault_id ON reminder_mutes (vault_id);
CREATE INDEX ix_documents_vault_status ON documents (vault_id, status);
CREATE INDEX ix_documents_change_seq ON documents (change_seq);
CREATE INDEX ix_documents_trashed ON documents (trashed_at);
CREATE INDEX ix_document_dates_document_id ON document_dates (document_id);
CREATE INDEX ix_document_tags_tag_id ON document_tags (tag_id);
CREATE UNIQUE INDEX uq_versions_original ON versions (lower(original_path));
CREATE INDEX ix_versions_sha256 ON versions (sha256);
CREATE INDEX ix_notes_document_id ON notes (document_id);
CREATE INDEX ix_shares_user_id ON shares (user_id);
CREATE INDEX ix_links_document_id ON links (document_id);
CREATE INDEX ix_events_document ON events (document_id, id);
CREATE INDEX ix_intake_items_message ON intake_items (message);
CREATE UNIQUE INDEX uq_intake_items_mail ON intake_items ("key") WHERE source = 'mail';
CREATE UNIQUE INDEX uq_intake_items_taken ON intake_items (source, "key") WHERE state = 'taken';
CREATE INDEX ix_intake_items_document ON intake_items (document_id);
CREATE UNIQUE INDEX uq_paperless_items_origin ON paperless_items (origin, paperless_id);
CREATE INDEX ix_paperless_items_document ON paperless_items (document_id);
CREATE INDEX ix_document_numbers_document ON document_numbers (document_id);
CREATE INDEX ix_document_numbers_compare ON document_numbers (kind, compare);
CREATE INDEX ix_related_high ON related (high_id);
CREATE INDEX ix_related_dismissed_high ON related_dismissed (high_id);
CREATE INDEX ix_pins_document ON pins (document_id);
CREATE INDEX ix_version_texts_document_id ON version_texts (document_id);
CREATE INDEX ix_version_info_document ON version_info (document_id, state);
CREATE INDEX ix_einvoices_document_id ON einvoices (document_id);
CREATE INDEX ix_deadline_snoozes_user_id ON deadline_snoozes (user_id);
CREATE UNIQUE INDEX uq_reminders_sent_date ON reminders_sent (date_id, user_id, stage, day) WHERE date_id IS NOT NULL;
CREATE UNIQUE INDEX uq_reminders_sent_person ON reminders_sent (user_id, stage, day) WHERE date_id IS NULL;
CREATE INDEX ix_reminders_sent_user_day ON reminders_sent (user_id, sent_day);
CREATE INDEX ix_link_documents_document ON link_documents (document_id);
DELETE FROM "sqlite_sequence";
INSERT INTO "sqlite_sequence" VALUES('vaults',10);
COMMIT;
PRAGMA user_version = 20;
